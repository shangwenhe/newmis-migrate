define('migrate:widget/header/header.jes', function(require, exports, module) {

  /**
   * @file: header.jes
   * @author: shangwenhe@itv.baidu.com
   * @date: 2017-05-05
   * @description: this is a <jes> file
   */
  /* eslint-disable */
  "use strict";
  
  module.exports = {};
  /* eslint-enable */

});
